<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post</title>
</head>
<body>
    <h1><?php echo e($post->title); ?></h1>
    <p><?php echo e($post->body); ?></p>
</body>
</html>
<?php /**PATH C:\laravel\laravel\opdr05\resources\views/post.blade.php ENDPATH**/ ?>